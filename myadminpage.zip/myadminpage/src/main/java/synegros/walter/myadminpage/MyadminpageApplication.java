package synegros.walter.myadminpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyadminpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyadminpageApplication.class, args);
	}

}
